

"""
Предобработка данных.
"""


import nltk  # Импорт библиотеки Natural Language Toolkit
from nltk.corpus import stopwords  # Импорт списка стоп-слов из NLTK
from nltk.tokenize import word_tokenize  # Импорт функции токенизации из NLTK
import string  # Импорт модуля string для работы с символами
import pyarrow.parquet as pq  # Импорт модуля pyarrow для работы с файлами формата Parquet

# Укажите путь к файлу .parquet
file_path = r"C:\Users\abbos\Desktop\reviews.parquet"  # Путь к файлу с отзывами о товарах
file_path1 = r"C:\Users\abbos\Desktop\return_reasons.parquet"  # Путь к файлу с причинами возврата товаров
file_path2 = r"C:\Users\abbos\Desktop\products.parquet"  # Путь к файлу с описаниями товаров
file_path3 = r"C:\Users\abbos\Desktop\returns.parquet"  # Путь к файлу с данными о возвратах товаров
file_path4 = r"C:\Users\abbos\Desktop\test.parquet"  # Путь к файлу с данными для тестирования модели

# Откройте файл .parquet
table = pq.read_table(file_path)  # Чтение файла Parquet с отзывами
table1 = pq.read_table(file_path1)  # Чтение файла Parquet с причинами возврата
table2 = pq.read_table(file_path2)  # Чтение файла Parquet с описаниями товаров
table3 = pq.read_table(file_path3)  # Чтение файла Parquet с данными о возвратах товаров
table4 = pq.read_table(file_path4)  # Чтение файла Parquet с данными для тестирования модели

# Преобразуйте данные в DataFrame (если необходимо)
reviews_df = table.to_pandas()  # Преобразование данных об отзывах в DataFrame
return_reasons_df = table1.to_pandas()  # Преобразование данных о причинах возврата в DataFrame
products_df = table2.to_pandas()  # Преобразование данных о товарах в DataFrame
returns_df = table3.to_pandas()  # Преобразование данных о возвратах товаров в DataFrame
test_df = table4.to_pandas()  # Преобразование тестовых данных в DataFrame

# Приведение текста к нижнему регистру
reviews_df['review_text'] = reviews_df['review_text'].str.lower()  # Приведение текста отзывов к нижнему регистру

# Удаление пунктуации (если текст не пустой)
reviews_df['review_text'] = reviews_df['review_text'].apply(lambda x: x.translate(str.maketrans('', '', string.punctuation)) if isinstance(x, str) else '')  # Удаление пунктуации из текста отзывов

# Выведем первые строки DataFrame, чтобы убедиться, что операции выполнились успешно
print(reviews_df.head())  # Вывод первых строк DataFrame с отзывами

# Теперь можем продолжить с обработкой текста данных.

# Вывод первых строк каждого DataFrame
print("reviews.parquet: \n", reviews_df.head())  # содержит отзывы клиентов о товарах на маркетплейсе
print("return_reasons.parquet: \n", return_reasons_df.head())    #  файл представляет собой словарь с уникальными причинами возврата товара и их идентификаторами
print("products.parquet: \n", products_df.head())   #  Файл с описаниями товаров, включая идентификатор товара
print("returns.parquet: \n", returns_df.head())   #   Сведения о возвратах товаров, включая уникальный идентификатор возврата
print("test.parquet: \n", test_df.head())    #   Файл с данными для тестирования модели
