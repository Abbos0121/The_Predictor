
"""
Это решение. Код загружает данные из файлов формата Parquet,
объединяет их, кодирует категориальные признаки, обучает модель
LightGBM на обучающем наборе данных, предсказывает вероятности
причин возврата для товаров из тестового набора и сохраняет результаты
в новый файл формата Parquet.
"""



import pandas as pd  # Импорт библиотеки pandas
from sklearn.model_selection import train_test_split  # Импорт функции train_test_split из sklearn для разделения данных на обучающий и тестовый наборы
from lightgbm import LGBMClassifier  # Импорт класса LGBMClassifier из библиотеки LightGBM для построения модели градиентного бустинга
from sklearn.preprocessing import LabelEncoder  # Импорт класса LabelEncoder из sklearn.preprocessing для кодирования категориальных признаков

# Загрузка данных из файлов Parquet
return_reasons_encoded_df = pd.read_parquet("return_reasons_encoded.parquet")  # Загрузка закодированных данных о причинах возврата
products_encoded_df = pd.read_parquet("products_encoded.parquet")  # Загрузка закодированных данных о продуктах
returns_encoded_df = pd.read_parquet("returns_encoded.parquet")  # Загрузка закодированных данных о возвратах
test_encoded_df = pd.read_parquet("test_encoded.parquet")  # Загрузка закодированных тестовых данных

# Объединение данных из разных таблиц
train_data = pd.merge(returns_encoded_df, return_reasons_encoded_df, on="id", how="left")  # Объединение данных о возвратах и причинах возврата
train_data = pd.merge(train_data, products_encoded_df, on="product_id", how="left")  # Объединение данных о возвратах и продуктах

# Применение Label Encoding к категориальным признакам
label_encoder = LabelEncoder()  # Создание объекта LabelEncoder для кодирования категориальных признаков
for column in ['product_id', 'comment', 'customer_id', 'reason', 'category_title', 'product_description']:
    train_data[column] = label_encoder.fit_transform(train_data[column])  # Кодирование категориальных признаков в числовые значения

# Разделение данных на обучающий и тестовый наборы
X = train_data.drop(columns=["id", "cause"])  # Отделение признаков от целевой переменной
y = train_data["cause"]  # Определение целевой переменной
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  # Разделение данных на обучающий и тестовый наборы

# Обучение модели LightGBM
model = LGBMClassifier()  # Инициализация модели LightGBM
model.fit(X_train, y_train)  # Обучение модели на обучающем наборе данных

# Сброс индексов в тестовом наборе данных
test_encoded_df.reset_index(drop=True, inplace=True)  # Сброс индексов для корректного объединения с результатами предсказаний

# Предсказание вероятностей возврата для каждого товара из тестового набора данных
probabilities = model.predict_proba(X_test)  # Предсказание вероятностей для классов в тестовом наборе данных

# Создание DataFrame для сохранения результатов предсказаний
result_df = pd.concat([
    test_encoded_df[['product_id', 'order_item_id']],  # Оставление идентификаторов товаров и заказов
    pd.DataFrame(probabilities, columns=[  # Добавление вероятностей причин возврата как столбцов
        'prob_return_reason_DEFECTED',
        'prob_return_reason_WRONG_ITEM',
        'prob_return_reason_BAD_QUALITY',
        'prob_return_reason_PHOTO_MISMATCH',
        'prob_return_reason_WRONG_SIZE'
    ])
], axis=1)

# Сохранение результатов в формате Parquet
result_df.to_parquet('result.parquet', index=False)  # Сохранение результатов предсказаний в файл формата Parquet




