

"""
Этот код загружает данные из файлов Parquet,
выполняет преобразования и сохраняет
обработанные данные в новых файлах Parquet.
"""



import pandas as pd  # Импорт библиотеки pandas под псевдонимом pd
from sklearn.preprocessing import LabelEncoder  # Импорт класса LabelEncoder из библиотеки sklearn.preprocessing
# Список категориальных признаков в каждом файле данных
categorical_features = {
    "return_reasons": ["reason"],  # Категориальный признак в файле return_reasons.parquet
    "products": ["category_id"],    # Категориальный признак в файле products.parquet
    "returns": ["cause"],           # Категориальный признак в файле returns.parquet
    "test": []                      # У файла test.parquet нет категориальных признаков
}

# Загрузка и обработка каждого файла данных
for df_name, features in categorical_features.items():  # Цикл по каждому элементу в словаре categorical_features
    # Загрузка данных из файла Parquet
    df = pd.read_parquet(f"{df_name}.parquet")  # Загрузка данных из файла Parquet с именем, указанным в df_name, в объект DataFrame с именем df

    # Преобразование столбца date_created в количество секунд с начала эпохи, если такой столбец присутствует
    if 'date_created' in df.columns:  # Проверка наличия столбца 'date_created' в DataFrame df
        df['date_created_seconds'] = (df['date_created'] - pd.Timestamp("1970-01-01")) // pd.Timedelta('1s')  # Преобразование столбца 'date_created' в количество секунд с начала эпохи и сохранение в новом столбце 'date_created_seconds'
        df.drop(columns=['date_created'], inplace=True)  # Удаление столбца 'date_created' из DataFrame df

    # Применение Label Encoding ко всем категориальным признакам
    label_encoder = LabelEncoder()  # Создание объекта LabelEncoder для кодирования категориальных признаков
    for feature in features:  # Цикл по категориальным признакам в списке features
        df[feature] = label_encoder.fit_transform(df[feature])  # Применение метода fit_transform() объекта LabelEncoder к столбцу DataFrame df, кодируя его категориальные значения

    # Сохранение закодированных данных в новый файл
    df.to_parquet(f"{df_name}_encoded.parquet", index=False)  # Сохранение обработанных данных в новый файл формата Parquet с добавлением суффикса "_encoded" к имени исходного файла
    print(df.dtypes)  # Вывод информации о типах данных в DataFrame df
